# Vim Config by Vu Nguyen Coder

[Note]
- Can run on both Window and Linux
- Run command :PlugInstall after pulling this resource

[Requirement]
- NodeJS
- Python
- Git
- vim-plug
- bat
